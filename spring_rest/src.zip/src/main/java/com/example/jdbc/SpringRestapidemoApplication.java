package com.example.jdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestapidemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestapidemoApplication.class, args);
	}

}
